document.getElementById('loginBtn').onclick = function() {
  window.location.href = "../login_web/login.html";
};
document.getElementById('instalacaoFeature').onclick = function() {
  window.location.href = "../pagina_web/Intalacao.html";
};
document.getElementById('vendaFeature').onclick = function() {
  window.location.href = "../pagina_web/venda.html";
};
document.getElementById('gestaoFeature').onclick = function() {
  window.location.href = "../pagina_web/gestao.html";
}