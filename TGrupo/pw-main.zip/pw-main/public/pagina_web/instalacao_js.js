// Botão voltar à página inicial
document.getElementById('voltarBtn').onclick = function() {
  window.location.href = 'front.html';
};